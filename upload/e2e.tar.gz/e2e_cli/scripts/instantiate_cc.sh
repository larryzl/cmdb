#!/bin/bash
# Copyright London Stock Exchange Group All Rights Reserved.
#
# SPDX-License-Identifier: Apache-2.0
#

set -e
CORE_LOGGING_LEVEL=ERROR
cc_version=$1
cc_name=$2
CHANNEL_NAME=$3
: ${cc_name:="vplus_ott_awards"}
if [ -z $cc_version ];then
        echo "Chiancode Version Is Null"
        exit 1
fi

echo ">>>>>>>>>>>Install Chiancode : $cc_name"

: ${CHANNEL_NAME:="mychannel"}
: ${TIMEOUT:="600"}
COUNTER=1
MAX_RETRY=5
ORDERER_CA=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/example.com/orderers/orderer.example.com/msp/tlscacerts/tlsca.example.com-cert.pem

echo "Channel name : "$CHANNEL_NAME


setGlobals () {

	if [ $1 -eq 0 -o $1 -eq 1 ] ; then
		CORE_PEER_LOCALMSPID="Org1MSP"
		CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt
		CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp
		if [ $1 -eq 0 ]; then
			CORE_PEER_ADDRESS=peer0.org1.example.com:7051
		else
			CORE_PEER_ADDRESS=peer1.org1.example.com:7051
		fi
	else
		CORE_PEER_LOCALMSPID="Org2MSP"
		CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org2.example.com/peers/peer0.org2.example.com/tls/ca.crt
		CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org2.example.com/users/Admin@org2.example.com/msp
		if [ $1 -eq 2 ]; then
			CORE_PEER_ADDRESS=peer0.org2.example.com:7051
		else
			CORE_PEER_ADDRESS=peer1.org2.example.com:7051
		fi
	fi

}

install_cc(){
        cc_name=$1
        cc_version=$2
        peer chaincode install -n $cc_name -v $cc_version -p github.com/hyperledger/fabric/examples/chaincode/go/${cc_name}
}

for env in 0 1 2 3 ; do
        setGlobals $env

        install_cc $cc_name $cc_version
        echo ">>>>>>>>>>>>>${CORE_PEER_ADDRESS}: Chiancode: $cc_name Version: $cc_version Install OK<<<<<<<<<"
done
sleep 10

setGlobals 0
peer chaincode instantiate -o orderer.example.com:7050 --tls true --cafile $ORDERER_CA -C ${CHANNEL_NAME} -n $cc_name -v $cc_version -c '{"Args":["init","a","100","b","200"]}' -P "OR     ('Org1MSP.member','Org2MSP.member')"
for env in 0 1 2 3; do
        setGlobals $env
        peer chaincode query -C $CHANNEL_NAME -n ${cc_name} -c  '{"Args":["AccountInfoByUser","TS_BLOCKCHAIN"]}'
        sleep 60
done
